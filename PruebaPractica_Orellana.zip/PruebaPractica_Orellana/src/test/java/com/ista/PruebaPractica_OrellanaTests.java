package com.ista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaPractica_OrellanaTests {

	@Test
	void contextLoads() {
	}

}
