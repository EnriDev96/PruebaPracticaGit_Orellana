package com.ista.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ista.model.Depto;

public interface DeptoRepository extends MongoRepository<Depto, Long>{

}
