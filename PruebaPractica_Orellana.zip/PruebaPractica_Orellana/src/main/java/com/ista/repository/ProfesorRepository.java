package com.ista.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ista.model.Profesor;

public interface ProfesorRepository extends  MongoRepository<Profesor, Long>{

}
