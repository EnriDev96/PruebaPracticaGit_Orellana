package com.ista.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Document(collection = "Profesor")
@Data
public class Profesor {
	private Long profesor_id;
	private Long depto_id;
	private String nombre;
	private String direccion;
	private String telefono;
	
	private Depto depto;
	private List<Profesor> listaprofesor;
	
	
	public Long getProfesor_id() {
		return profesor_id;
	}
	public void setProfesor_id(Long profesor_id) {
		this.profesor_id = profesor_id;
	}
	public Long getDepto_id() {
		return depto_id;
	}
	public void setDepto_id(Long depto_id) {
		this.depto_id = depto_id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public Depto getDepto() {
		return depto;
	}
	public void setDepto(Depto depto) {
		this.depto = depto;
	}
	public List<Profesor> getListaprofesor() {
		return listaprofesor;
	}
	public void setListaprofesor(List<Profesor> listaprofesor) {
		this.listaprofesor = listaprofesor;
	}
	
}
