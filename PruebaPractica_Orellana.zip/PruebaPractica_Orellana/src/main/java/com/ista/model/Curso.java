package com.ista.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Document(collection = "Curso")
@Data
public class Curso {
	private Long curso_id;
	private Long depto_id;
	private String nombre;
	private String nivel;
	private String descripcion;
	
	private Profesor profesor;
	private List<Curso> listacurso;
	
	public Long getCurso_id() {
		return curso_id;
	}
	public void setCurso_id(Long curso_id) {
		this.curso_id = curso_id;
	}
	public Long getDepto_id() {
		return depto_id;
	}
	public void setDepto_id(Long depto_id) {
		this.depto_id = depto_id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getNivel() {
		return nivel;
	}
	public void setNivel(String nivel) {
		this.nivel = nivel;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Profesor getProfesor() {
		return profesor;
	}
	public void setProfesor(Profesor profesor) {
		this.profesor = profesor;
	}
	public List<Curso> getListacurso() {
		return listacurso;
	}
	public void setListacurso(List<Curso> listacurso) {
		this.listacurso = listacurso;
	}
	
	

}
