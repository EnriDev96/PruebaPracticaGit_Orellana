package com.ista.service;

import com.ista.model.Curso;

public interface CursoService extends GenericService<Curso, Long>{

}
