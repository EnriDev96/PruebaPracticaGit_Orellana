package com.ista.service;

import com.ista.model.Profesor;

public interface ProfesorService extends GenericService<Profesor, Long>{

}
