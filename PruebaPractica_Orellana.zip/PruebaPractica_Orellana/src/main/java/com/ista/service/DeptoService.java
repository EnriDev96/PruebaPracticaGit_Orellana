package com.ista.service;

import com.ista.model.Depto;

public interface DeptoService extends GenericService<Depto, Long>{

}
