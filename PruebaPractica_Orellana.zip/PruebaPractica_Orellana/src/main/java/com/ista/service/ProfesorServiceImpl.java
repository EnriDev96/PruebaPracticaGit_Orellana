package com.ista.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.ista.repository.ProfesorRepository;
import com.ista.model.Profesor;

@Service
public class ProfesorServiceImpl extends GenericServiceImpl<Profesor, Long> implements ProfesorService{
	
	@Autowired
	ProfesorRepository profesorRepository;
	
	@Override
	public CrudRepository<Profesor, Long> getDao() {
		return profesorRepository;
	}

}
