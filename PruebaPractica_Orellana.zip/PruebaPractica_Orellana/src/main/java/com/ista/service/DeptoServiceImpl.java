package com.ista.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.ista.model.Depto;
import com.ista.repository.DeptoRepository;

@Service
public class DeptoServiceImpl extends GenericServiceImpl<Depto, Long> {

	@Autowired
	DeptoRepository deptoRepository;
	
	@Override
	public CrudRepository<Depto, Long> getDao() {
		return deptoRepository;
	}

}
